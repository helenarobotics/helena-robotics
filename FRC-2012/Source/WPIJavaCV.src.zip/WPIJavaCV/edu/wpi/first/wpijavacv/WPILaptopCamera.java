package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_highgui;

public class WPILaptopCamera extends WPIDisposable
{
  opencv_highgui.CvCapture cam;

  public WPILaptopCamera()
  {
    this.cam = opencv_highgui.cvCreateCameraCapture(0);
  }

  public WPIColorImage getCurrentFrame() {
    return new WPIColorImage(opencv_highgui.cvQueryFrame(this.cam));
  }

  protected void disposed()
  {
  }
}