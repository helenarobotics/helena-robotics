package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_core;
import com.googlecode.javacv.cpp.opencv_imgproc;

import java.util.ArrayList;

public class WPIBinaryImage extends WPIImage
{
  protected WPIBinaryImage(opencv_core.IplImage image)
  {
    super(image);
  }

  public WPIBinaryImage getAnd(WPIBinaryImage image2)
  {
    validateDisposed();

    opencv_core.IplImage result = opencv_core.IplImage.create(this.image.cvSize(), this.image.depth(), 1);
    opencv_core.cvAnd(this.image, image2.image, result, null);
    return new WPIBinaryImage(result);
  }

  public void and(WPIBinaryImage image2)
  {
    validateDisposed();

    opencv_core.cvAnd(this.image, image2.image, this.image, null);
  }

  public WPIBinaryImage getOr(WPIBinaryImage image2)
  {
    validateDisposed();

    opencv_core.IplImage result = opencv_core.IplImage.create(this.image.cvSize(), this.image.depth(), 1);
    opencv_core.cvOr(this.image, image2.image, result, null);
    return new WPIBinaryImage(result);
  }

  public void or(WPIBinaryImage image2)
  {
    validateDisposed();

    opencv_core.cvOr(this.image, image2.image, this.image, null);
  }

  public void invert()
  {
    validateDisposed();

    opencv_core.cvInv(this.image, this.image);
  }

  public WPIBinaryImage getInverse()
  {
    validateDisposed();

    opencv_core.IplImage result = opencv_core.IplImage.create(this.image.cvSize(), this.image.depth(), 1);
    opencv_core.cvInv(this.image, result);
    return new WPIBinaryImage(result);
  }

  public void dilate(int iterations)
  {
    validateDisposed();

    opencv_imgproc.cvDilate(this.image, this.image, null, iterations);
  }

  public WPIBinaryImage getDilated(int iterations)
  {
    validateDisposed();

    opencv_core.IplImage result = opencv_core.IplImage.create(this.image.cvSize(), this.image.depth(), 1);
    opencv_imgproc.cvDilate(this.image, result, null, iterations);
    return new WPIBinaryImage(result);
  }

  public void erode(int iterations)
  {
    validateDisposed();

    opencv_imgproc.cvErode(this.image, this.image, null, iterations);
  }

  public WPIBinaryImage getEroded(int iterations)
  {
    validateDisposed();

    opencv_core.IplImage result = opencv_core.IplImage.create(this.image.cvSize(), this.image.depth(), 1);
    opencv_imgproc.cvErode(this.image, result, null, iterations);
    return new WPIBinaryImage(result);
  }

  public WPIContour[] findContours()
  {
    validateDisposed();

    opencv_core.IplImage tempImage = opencv_core.IplImage.create(this.image.cvSize(), this.image.depth(), 1);

    opencv_core.cvCopy(this.image, tempImage);

    final opencv_core.CvMemStorage storage = opencv_core.CvMemStorage.create();
    WPIMemoryPool pool = new WPIMemoryPool()
    {
      protected void disposed()
      {
        opencv_core.cvClearMemStorage(storage);
        storage.release();
      }
    };
    opencv_core.CvSeq contours = new opencv_core.CvSeq();
    opencv_imgproc.cvFindContours(tempImage, storage, contours, 256, 1, 4);
    ArrayList results = new ArrayList();
    while (!isNull(contours)) {
      WPIContour contour = new WPIContour(opencv_core.cvCloneSeq(contours, storage));
      results.add(contour);
      pool.addToPool(contour);
      contours = contours.h_next();
    }

    tempImage.release();
    WPIContour[] array = new WPIContour[results.size()];
    return (WPIContour[])results.toArray(array);
  }
}