package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_core;
import com.googlecode.javacv.cpp.opencv_core.CvSeq;
import com.googlecode.javacv.cpp.opencv_core.IplImage;
import java.awt.image.BufferedImage;

public class WPIColorImage extends WPIImage
{
  private WPIGrayscaleImage red;
  private WPIGrayscaleImage blue;
  private WPIGrayscaleImage green;

  public WPIColorImage(BufferedImage imageSrc)
  {
    super(imageSrc);
  }

  WPIColorImage(opencv_core.IplImage imageSrc) {
    super(imageSrc);
  }

  public void drawContour(WPIContour c, WPIColor color, int thickness)
  {
    opencv_core.cvDrawContours(this.image, c.getCVSeq(), color.toCvScalar(), color.toCvScalar(), 100, thickness, 8);
  }

  public void drawContours(WPIContour[] c, WPIColor color, int thickness)
  {
    for (WPIContour con : c)
      drawContour(con, color, thickness);
  }

  public void drawLine(WPIPoint p1, WPIPoint p2, WPIColor color, int thickness)
  {
    opencv_core.cvLine(this.image, p1.getCvPoint(), p2.getCvPoint(), color.toCvScalar(), thickness, 8, 0);
  }

  public void drawPolygon(WPIPolygon p, WPIColor color, int thickness)
  {
    opencv_core.cvDrawContours(this.image, p.getCVSeq(), color.toCvScalar(), color.toCvScalar(), 100, thickness, 8);
  }

  public void drawPoint(WPIPoint p, WPIColor color, int thickness)
  {
    opencv_core.cvDrawCircle(this.image, p.getCvPoint(), thickness, color.toCvScalar(), -1, 8, 0);
  }

  public void drawPoints(WPIPoint[] p, WPIColor color, int thickness)
  {
    for (int i = 0; i < p.length; i++)
      drawPoint(p[i], color, thickness);
  }

  public void drawPolygons(WPIPolygon[] p, WPIColor color, int thickness)
  {
    for (WPIPolygon polygon : p)
      if ((polygon != null) && (!polygon.getCVSeq().isNull()))
        drawPolygon(polygon, color, thickness);
  }

  public void drawRect(int x, int y, int width, int height, WPIColor color, int thickness)
  {
    opencv_core.cvDrawRect(this.image, opencv_core.cvPoint(x, y), opencv_core.cvPoint(x + width, y + height), color.toCvScalar(), thickness, 8, 0);
  }

  private void generateChannels() {
    if (this.red == null) {
      opencv_core.IplImage redChannel = opencv_core.IplImage.create(this.image.cvSize(), 8, 1);
      opencv_core.IplImage greenChannel = opencv_core.IplImage.create(this.image.cvSize(), 8, 1);
      opencv_core.IplImage blueChannel = opencv_core.IplImage.create(this.image.cvSize(), 8, 1);
      opencv_core.cvSplit(this.image, blueChannel, greenChannel, redChannel, null);
      this.red = new WPIGrayscaleImage(redChannel);
      this.blue = new WPIGrayscaleImage(blueChannel);
      this.green = new WPIGrayscaleImage(greenChannel);
    }
  }

  public WPIGrayscaleImage getRedChannel()
  {
    generateChannels();
    return this.red;
  }

  public WPIGrayscaleImage getBlueChannel()
  {
    generateChannels();
    return this.blue;
  }

  public WPIGrayscaleImage getGreenChannel()
  {
    generateChannels();
    return this.green;
  }
}