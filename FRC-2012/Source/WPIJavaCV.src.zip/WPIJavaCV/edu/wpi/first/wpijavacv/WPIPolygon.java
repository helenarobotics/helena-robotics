package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_core;
import com.googlecode.javacv.cpp.opencv_core.CvPoint;
import com.googlecode.javacv.cpp.opencv_core.CvRect;
import com.googlecode.javacv.cpp.opencv_core.CvSeq;
import com.googlecode.javacv.cpp.opencv_imgproc;

public class WPIPolygon extends WPIDisposable
{
  opencv_core.CvSeq polygon;
  opencv_core.CvRect boundingRect;

  WPIPolygon(opencv_core.CvSeq data)
  {
    this.polygon = data;
  }

  opencv_core.CvSeq getCVSeq() {
    return this.polygon;
  }

  public WPIPoint[] getPoints()
  {
    opencv_core.CvPoint points = new opencv_core.CvPoint(getNumVertices());
    WPIPoint[] wpiPoints = new WPIPoint[getNumVertices()];
    opencv_core.cvCvtSeqToArray(this.polygon, points.position(0), opencv_core.CV_WHOLE_SEQ);
    for (int j = 0; j < getNumVertices(); j++)
    {
      wpiPoints[j] = new WPIPoint(points.position(j).x(), points.position(j).y());
    }

    return wpiPoints;
  }

  public int getWidth()
  {
    if (this.boundingRect == null) {
      this.boundingRect = opencv_imgproc.cvBoundingRect(this.polygon, 0);
    }
    return this.boundingRect.width();
  }

  public int getHeight()
  {
    if (this.boundingRect == null) {
      this.boundingRect = opencv_imgproc.cvBoundingRect(this.polygon, 0);
    }
    return this.boundingRect.height();
  }

  public int getX()
  {
    if (this.boundingRect == null) {
      this.boundingRect = opencv_imgproc.cvBoundingRect(this.polygon, 0);
    }
    return this.boundingRect.x();
  }

  public int getY()
  {
    if (this.boundingRect == null) {
      this.boundingRect = opencv_imgproc.cvBoundingRect(this.polygon, 0);
    }
    return this.boundingRect.y();
  }

  public int getNumVertices()
  {
    return this.polygon.total();
  }

  public boolean isConvex()
  {
    return opencv_imgproc.cvCheckContourConvexity(this.polygon) != 0;
  }

  public int getArea()
  {
    return Math.abs((int)opencv_imgproc.cvContourArea(this.polygon, opencv_core.CV_WHOLE_SEQ, -1));
  }

  public int getPerimeter()
  {
    return (int)opencv_imgproc.cvArcLength(this.polygon, opencv_core.CV_WHOLE_SEQ, -1);
  }

  public void disposed() {
    this.polygon.deallocate();
  }
}