package edu.wpi.first.wpijavacv;

import com.googlecode.javacpp.Pointer;

public abstract class WPIDisposable
{
  private WPIMemoryPool pool;
  private boolean disposed;

  public WPIDisposable()
  {
    this.pool = null;

    this.disposed = false;
  }

  protected void setPool(WPIMemoryPool pool)
  {
    this.pool = pool;
  }

  protected WPIMemoryPool getPool() {
    return this.pool;
  }

  public void dispose()
  {
    if (!this.disposed) {
      this.disposed = true;
      disposed();
      if (this.pool != null)
        this.pool.removeFromPool(this);
    }
  }

  protected abstract void disposed();

  public boolean isDisposed()
  {
    return this.disposed;
  }

  protected void validateDisposed()
  {
    if (this.disposed)
      throw new DisposedException(this + " has been disposed");
  }

  protected void validateDisposed(String message)
  {
    if (this.disposed)
      throw new DisposedException(message);
  }

  protected static boolean isNull(Pointer pointer)
  {
    return (pointer == null) || (pointer.isNull());
  }

  protected static void free(Pointer pointer)
  {
    if ((pointer != null) && (!pointer.isNull()))
      pointer.deallocate();
  }

  protected void finalize()
    throws Throwable
  {
    dispose();
    super.finalize();
  }

  public static class DisposedException extends RuntimeException
  {
    public DisposedException(String message)
    {
      super();
    }
  }
}