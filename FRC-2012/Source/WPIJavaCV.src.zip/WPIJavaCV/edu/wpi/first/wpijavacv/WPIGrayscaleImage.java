package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_core;
import com.googlecode.javacv.cpp.opencv_imgproc;

public class WPIGrayscaleImage extends WPIImage
{
  WPIGrayscaleImage(opencv_core.IplImage imageSrc)
  {
    super(imageSrc);
  }

  public WPIBinaryImage getThreshold(int threshold)
  {
    validateDisposed();

    opencv_core.IplImage bin = opencv_core.IplImage.create(this.image.cvSize(), 8, 1);
    opencv_imgproc.cvThreshold(this.image, bin, threshold, 255.0D, 0);
    return new WPIBinaryImage(bin);
  }

  public WPIBinaryImage getThresholdInverted(int threshold)
  {
    validateDisposed();

    opencv_core.IplImage bin = opencv_core.IplImage.create(this.image.cvSize(), 8, 1);
    opencv_imgproc.cvThreshold(this.image, bin, threshold, 255.0D, 1);
    return new WPIBinaryImage(bin);
  }
}