package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_highgui;

public class WPIJavaCVUtils
{
  public static void waitForKey(char key)
  {
    while (opencv_highgui.cvWaitKey() != key);
  }

  public static char waitForAnyKey()
  {
    return (char)opencv_highgui.cvWaitKey();
  }

  public static boolean keyIsPressed(char key, int timeoutMillis)
  {
    return opencv_highgui.cvWaitKey(timeoutMillis) == key;
  }
}