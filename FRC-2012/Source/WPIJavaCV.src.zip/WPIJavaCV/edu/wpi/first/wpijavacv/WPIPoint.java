package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_core;

public class WPIPoint
{
  opencv_core.CvPoint p;

  public WPIPoint(int x, int y)
  {
    this.p = new opencv_core.CvPoint(new int[] { x, y });
  }

  WPIPoint(opencv_core.CvPoint c) {
    this.p = c;
  }

  public int getX()
  {
    return this.p.x();
  }

  public int getY()
  {
    return this.p.y();
  }

  opencv_core.CvPoint getCvPoint() {
    return this.p;
  }

  public String toString()
  {
    return this.p.toString();
  }
}