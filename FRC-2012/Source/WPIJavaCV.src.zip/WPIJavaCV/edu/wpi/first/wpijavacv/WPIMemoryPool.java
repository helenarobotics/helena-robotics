package edu.wpi.first.wpijavacv;

public abstract class WPIMemoryPool extends WPIDisposable
{
  private int remaining;

  public synchronized void addToPool(WPIDisposable disposable)
  {
    validateDisposed();
    disposable.setPool(this);
    this.remaining += 1;
  }

  public synchronized void removeFromPool(WPIDisposable disposable)
  {
    validateDisposed();
    disposable.setPool(null);
    if (--this.remaining <= 0)
      dispose();
  }
}