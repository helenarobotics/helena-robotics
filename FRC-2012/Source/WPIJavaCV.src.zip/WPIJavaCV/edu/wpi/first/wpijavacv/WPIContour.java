package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_core;
import com.googlecode.javacv.cpp.opencv_imgproc;

public class WPIContour extends WPIDisposable
{
  opencv_core.CvSeq contours;
  opencv_core.CvRect rect;

  WPIContour(opencv_core.CvSeq contours)
  {
    this.contours = contours;
  }

  opencv_core.CvSeq getCVSeq()
  {
    return this.contours;
  }

  public int getHeight()
  {
    if ((this.rect == null) || (this.rect.isNull())) {
      this.rect = opencv_imgproc.cvBoundingRect(this.contours, 1);
    }
    return this.rect.height();
  }

  public int getWidth()
  {
    if ((this.rect == null) || (this.rect.isNull())) {
      this.rect = opencv_imgproc.cvBoundingRect(this.contours, 1);
    }
    return this.rect.width();
  }

  public int getX()
  {
    if ((this.rect == null) || (this.rect.isNull())) {
      this.rect = opencv_imgproc.cvBoundingRect(this.contours, 1);
    }
    return this.rect.x();
  }

  public int getY()
  {
    if ((this.rect == null) || (this.rect.isNull())) {
      this.rect = opencv_imgproc.cvBoundingRect(this.contours, 1);
    }
    return this.rect.y();
  }

  public synchronized WPIPolygon approxPolygon(double percentAccuracy)
  {
    WPIPolygon polygon = new WPIPolygon(opencv_imgproc.cvApproxPoly(this.contours, this.contours.header_size(), this.contours.storage(), 0, percentAccuracy, 0));
    if (getPool() != null) {
      getPool().addToPool(polygon);
    }
    return polygon;
  }

  public int getlength()
  {
    return (int)opencv_imgproc.cvContourPerimeter(this.contours);
  }

  public void disposed() {
    this.contours.deallocate();
  }
}