package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_highgui;

public class WPIWindow
{
  private static int count = 0;
  private String name;

  public WPIWindow()
  {
    count += 1;

    this.name = ("Window " + count);
    opencv_highgui.cvNamedWindow(this.name);
  }

  public WPIWindow(String name)
  {
    this.name = name;
  }

  public void showImage(WPIImage image)
  {
    if (image != null)
      opencv_highgui.cvShowImage(this.name, image.image);
    else opencv_highgui.cvShowImage(this.name, null);
  }
}