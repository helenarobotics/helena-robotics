package edu.wpi.first.wpijavacv;

import com.googlecode.javacv.cpp.opencv_core;
import java.awt.image.BufferedImage;

public class WPIImage extends WPIDisposable
{
  protected opencv_core.IplImage image;

  public WPIImage(BufferedImage image)
  {
    this(opencv_core.IplImage.createFrom(image));
  }

  public WPIImage(opencv_core.IplImage image)
  {
    this.image = image;
  }

  public int getWidth()
  {
    validateDisposed();

    return this.image.width();
  }

  public int getHeight()
  {
    validateDisposed();

    return this.image.height();
  }

  public BufferedImage getBufferedImage()
  {
    validateDisposed();

    return this.image.getBufferedImage();
  }

  protected void disposed()
  {
    this.image.release();
  }
}